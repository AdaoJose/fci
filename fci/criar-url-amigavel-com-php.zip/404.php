<html>
	<head>
		<title>404</title>
		<meta charset="utf-8">
	</head>
	<body>
		<h1>Página não encontrada</h1>
	</body>
</html>