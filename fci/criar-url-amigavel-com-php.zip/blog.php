<html>
	<head>
		<title>Blog</title>
		<meta charset="utf-8">
	</head>
	<body>
		<h1>Blog</h1>
	</body>
</html>