# Guia do usuário do CodeIgniter em Português do Brasil

#  Instruções para tradução da documentação

## Como fazer para colaborar?

Primeiramente, você deve dar um [fork](http://help.github.com/fork-a-repo/) no [projeto](https://github.com/CIBr/User-Guide-CodeIgniter-PtBr) para a sua conta. Com isso, você estará livre para fazer as traduções para o português.

Quando finalizar algo, você deve dar um [pull request](https://help.github.com/articles/about-pull-requests/) neste repositório para o seu conteúdo ser revisado e aprovado. Com isso, a sua tradução estará no repositório principal e com os seus devidos créditos.

Depois de aprovado, poderá ser visto em https://cibr.github.io/User-Guide-CodeIgniter-PtBr. Todos os colaboradores serão citados e terão seus créditos mantidos.

## Como saber se o que eu estou traduzindo não está sendo traduzido por alguém?

Uma lista pode ser acompanhada no trello em: https://trello.com/b/s2JpLhqc


## Créditos

* Marcelo Diniz / [@marcelod](https://twitter.com/marcelo_leo27) / [github](http://github.com/marcelod)
* Alisson Zampietro / [github](https://github.com/alissonzampietro)
* Vitors Silva Lima / [github](https://github.com/vitorsilvalima)
* Marcos Pereira / [github](https://github.com/mvnp)
* Cesar Edenir Balzer / [github](https://github.com/CesarBalzer)
* Rafael Pinheiro / [github](https://github.com/rafaelwendel)
* Tadeu Carnevalli / [github](https://github.com/carnevalli)
* Marcos Baesse / [github](https://github.com/marcosbaesse)
* Cláudio Neto / [github](https://github.com/crcneto)

https://github.com/CIBr/User-Guide-CodeIgniter-PtBr/graphs/contributors

e para esse READE.md https://github.com/railsgirlsmaceio/railsgirlsguides/blob/gh-pages/README.md